import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String marca, modelo;
        double veloMax, gastoGasPorLitro, distancia;
        int opc;

        System.out.println("Ingresa la marca de tu carro:");
        marca = sc.nextLine();

        System.out.println("Ingresa el modelo de tu " + marca + ":");
        modelo = sc.nextLine();

        System.out.println("Ingresa la velocidad máxima de tu " + modelo + ":");
        veloMax = sc.nextDouble();

        System.out.println("Ingresa el gasto de gasolina por litro de tu " + modelo +":");
        gastoGasPorLitro = sc.nextDouble();

        Carro Carro1 = new Carro(marca, modelo, veloMax, gastoGasPorLitro);

        System.out.println("\n --- Informacion del Automovil ---");
        System.out.println("Marca: " + Carro1.getMarca());
        System.out.println("Modelo: " + Carro1.getModelo());
        System.out.println("Velocidad Máxima: " + Carro1.getVelocidadMaxima());
        System.out.println("Gasto de Gasolina por Litro: " + Carro1.getGastoGasolinaPorLitro());

        do{
            System.out.println("\n --- Menú ---");
            System.out.println("1. Cambiar marca.");
            System.out.println("2. Cambiar modelo.");
            System.out.println("3. Cambiar velocidad máxima.");
            System.out.println("4. Cambiar gasto de gasolina por litro.");
            System.out.println("5. Salir");
            System.out.print("Elige una opción: ");
            opc = sc.nextInt();
            sc.nextLine(); // Para eliminar el bug

            switch (opc) {
                case 1:
                    System.out.println("Ingresa la marca: ");
                    marca = sc.nextLine();

                    Carro1.setMarca(marca);
                    break;

                case 2:
                    System.out.println("Ingresa el modelo: ");
                    modelo = sc.nextLine();

                    Carro1.setModelo(modelo);
                    break;

                case 3:
                    System.out.println("Ingresa la velocidad máxima: ");
                    veloMax = sc.nextDouble();

                    Carro1.setVelocidadMaxima(veloMax);
                    break;

                case 4:
                    System.out.println("Ingresa el gasto por gasolina: ");
                    gastoGasPorLitro = sc.nextDouble();

                    Carro1.setGastoGasolinaPorLitro(gastoGasPorLitro);
                    break;

                case 5:
                    break;

                default:
                    System.out.println("Opción inválida.");
                    break;
            }

        }while (opc != 5);

        System.out.println("\n --- Informacion del Automovil ---");
        System.out.println("Marca: " + Carro1.getMarca());
        System.out.println("Modelo: " + Carro1.getModelo());
        System.out.println("Velocidad Máxima: " + Carro1.getVelocidadMaxima());
        System.out.println("Gasto de Gasolina por Litro: " + Carro1.getGastoGasolinaPorLitro());

        System.out.println("\nIngresa la distancia recorrida en km:");
        distancia = sc.nextDouble();

        System.out.println("Gasto de Gasolina: " + Carro1.calcularGastoDeGasolina(distancia));

        sc.close();
    }
}